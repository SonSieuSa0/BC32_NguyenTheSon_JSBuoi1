/**Mô hình 3 khối
 * Đầu vào:
 * Tạo biến number1 = 25
 * Tạo biến number2 = 30
 * Tạo biến number3 = 35
 * Tạo biến number4 = 40
 * Tạo biến number5 = 45 
 * * Các bước xử lý:
 * Giá trị trung bình của 5 số là chia cho 5
 * giaTri1 = number1 / 5
 * giaTri2 = number2 / 5
 * giaTri3 = number3 / 5
 * giaTri4 = number4 / 5
 * giaTri5 = number5 / 5
 * 
 * Đầu ra:
 * Thông báo kết quả 5 giá trị
 */

var number1 = 25;
var number2 = 30;
var number3 = 35;
var number4 = 40;
var number5 = 45;
giaTri1 = number1 / 5;
giaTri2 = number2 / 5;
giaTri3 = number3 / 5;
giaTri4 = number4 / 5;
giaTri5 = number5 / 5;

console.log("GiaTri 1: " + giaTri1);
console.log("GiaTri 2: " + giaTri2);
console.log("GiaTri 3: " + giaTri3);
console.log("GiaTri 4: " + giaTri4);
console.log("GiaTri 5: " + giaTri5);