/**Mô hình 3 khối
 * Đầu vào:
 * tạo biến number1 = 27
 * tạo biến number2 = 93
 * 
 * Các bước xử lý:
 * - Tạo biến hangChuc = Math.floor(n % 100 / 10)
 * - Tạo biến hangDV =  n % 10
 * 
 * Đầu ra:
 * Thông báo kết quả console
 */

var number1 = 27;
var hangChuc = Math.floor(27 / 10);
var hangDV = 27 % 10;

// console.log(hangChuc, hangDV);

var tong = hangChuc + hangDV;

console.log("Tổng ký số 27 :    " + tong);


var number2 = 93;
var hangChuc = Math.floor(93 / 10);
var hangDV = 93 % 10;

var tong = hangChuc + hangDV;
console.log("Tổng ký số 93 :    " + tong);