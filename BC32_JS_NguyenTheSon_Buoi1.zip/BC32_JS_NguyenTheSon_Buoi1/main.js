console.log("Hello CyberSoft!");
console.log("Nguyen The Son");

/** Variable ( Biến )
 * = phép gán
 * Tạo biến phải khai báo var + tên biến, theo giá trị đi kèm
 * tên biến ghi liền, không có số ở đầu
 */

/**Kiểu dữ liệu:
 * - string: trong dấu nháy ""
 * - number: ngoài dấu nháy
 * - boolean (true/false) luận lý đúng/sai
 * - undefined: không xác định
 * - null
 */
//nối chuỗi thì thêm dấu +
var username = "CyberSoft";
console.log("user: " + username);

var address = "112 Cao Thang";
console.log("diachi: " + address);

var numberStudent = 30;
console.log("so:" + numberStudent);

var isLogin = true;
//tạo biến
var age;
// cập nhật giá trị mới cho biến đã tạo
age = 18;
console.log("tuoi" + age);

var fullname = null;
console.log(fullname);

/**các loại toán tử
 * :+ nối chuỗi
 * :- dấu trừ 
 * :* dấu nhân
 * :/ dấu chia lấy phần nguyên
 * :% dấu chia lấy phần dư
 * :++ tăng 1 đơn vị
 * :-- giảm 1 đơn vị
 */

var number1 = 10;
var number2 = 5;

var tong = number1 + number2;
console.log("tong:" + tong);

var hieu = number1 - number2;
console.log("hieu:" + hieu);

var tich = number1 * number2;
console.log("tich:" + tich);

var thuong = number1 / number2;
console.log("thuong:" + thuong);

var chiaLayDu = number1 % number2;
console.log("chia lay du:" + chiaLayDu);

// var count = 0;
// console.log(count);
// // count = count + 1;
// count++;
// console.log(count);

var count = 0;
var newCount = count++;
console.log(newCount);

var number = 0;
number += 1;
console.log("number:" + number);

var a;
var b = 2;
a = 4;
b = ++b + ++a;
console.log(a);
console.log(b);

/** Hằng số (const)
 * ES6
 */

const PI = 3.14;