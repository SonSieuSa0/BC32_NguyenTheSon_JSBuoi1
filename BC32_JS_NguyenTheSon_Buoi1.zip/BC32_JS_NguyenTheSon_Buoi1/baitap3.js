var a, b, c;

a = 10;
a += a;
console.log(a);

b = ++a + 5;
c = a++ + 5;
console.log(a);

a = 0;
console.log(b);
console.log(c);
