/**mô hình 3 khối
 * Đầu vào:
 * - Tao bien canh1 = 3
 * - Tao bien canh2 = 4
 * 
 * Các bước xử lý: can bac hai tong binh phuong 2 canh goc vuong
 *  - Tao bien canhHuyen co gia tri la 0
 *  - canhHuyen = canh1 * canh 1 + canh2 * canh2
 *  - Can bac 2 cho canhHuyen (Math.sqrt())
 * 
 * Đầu ra:
 * - Thong bao ket qua canhHuyen = ?
 */

var canh1 = 3;
var canh2 = 4;
var canhHuyen = 0;
canhHuyen = canh1 * canh1 + canh2 * canh2;
canhHuyen = Math.sqrt(canhHuyen);
console.log(canhHuyen);