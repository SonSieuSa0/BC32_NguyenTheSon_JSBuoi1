/**Mô hình 3 khối
 * Đầu vào:
 * Tạo biến number1 = 23500

 * Các bước xử lý:
 * Tạo biến usd1 = number 1 * 1
 * Tạo biến usd2 = number 1 * 2
 * Tạo biến usd3 = number 1 * 3
 * Đầu ra:
 * Thông báo kết quả usd
 */

var number1 = 23500;
usd1 = number1 * 1;
usd2 = number1 * 2;
usd3 = number1 * 3;
console.log("1 USD :" + usd1);
console.log("2 USD :" + usd2);
console.log("3 USD :" + usd3);
