/**Mô hình 3 khối
 * Đầu vào:
 * tạo biến lương 1 ngày luong1 = 100000
 * tạo biến số ngày làm ngay1 = 1; ngay2 = 2; ngay30 = 30;
 * 
 * Các bước xử lý:
 * tạo biến luongNv = 0
 * tạo biến lương 1 ngày có giá trị là 100000
 * tạo biến số ngày làm có giá trị từ 1 đến 30
 * luongNv = luong1 * ngay1; luong1 * ngay2; luong1 * ngay30;
 * Đầu ra:
 * thông báo kết quả tính lương nhân viên
 * 
 */


var luong1 = 100000;
var ngay1 = 1;
var ngay2 = 2;
var ngay30 = 30;
var luongNv1 = 0;
var luongNv2 = 0;
var luongNv30 = 0;
luongNv1 = luong1 * ngay1;
luongNv2 = luong1 * ngay2;
luongNv30 = luong1 * ngay30;
console.log("LuongNgay1: " + luongNv1);
console.log("LuongNgay2: " + luongNv2);
console.log("LuongNgay30: " + luongNv30);
