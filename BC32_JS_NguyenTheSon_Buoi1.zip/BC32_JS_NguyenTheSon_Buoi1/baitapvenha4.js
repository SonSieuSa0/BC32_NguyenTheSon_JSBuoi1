/**Mô hình 3 khối
 * Đầu vào:
 * tạo biến chieuDai = 3
 * tại biến chieuRong = 5
 * Các bước xử lý:
 * dienTich = chieuDai * chieuRong
 * chuVi = (chieuDai + chieuRong) * 2
 * Đầu ra:
 * Thông báo kết quả dienTich,chuVi
 */

var chieuDai = 3;
var chieuRong = 5;
dienTich = chieuDai * chieuRong;
chuVi = (chieuDai + chieuRong) * 2;
console.log("Dien tich : " + dienTich);
console.log("Chu Vi : " + chuVi);