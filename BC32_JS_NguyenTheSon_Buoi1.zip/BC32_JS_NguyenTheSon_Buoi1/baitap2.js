/** Giả sử:
 * n = 679 | 6 + 7 + 9
 * 
 * Đầu vào:
 * - Tạo biến n gán giá trị 123
 * 
 * Xử lý:
 * - Tạo biến hangTram =  Math.floor(n / 100)
 * - Tạo biến hangChuc = Math.floor(n % 100 / 10)
 * - Tạo biến hangDV =  n % 10
 * 
 * 
 * Đầu ra:
 * - Thông báo kết quả ra console
 * 
 */

var n = 679;
var hangTram = Math.floor(679 / 100);
var hangChuc = Math.floor(679 % 100 / 10);
var hangDV = 679 % 10;

console.log(hangTram, hangChuc, hangDV);

var tong = hangTram + hangChuc + hangDV;

console.log("Tong: " + tong);